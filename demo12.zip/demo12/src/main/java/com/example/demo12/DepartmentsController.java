package com.example.demo12;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DepartmentsController {

    @FXML private TextField departmentIdField;
    @FXML private TextField departmentNameField;
    @FXML private TextField locationIdField;
    @FXML private TableView<Department> departmentsTable;
    @FXML private TableColumn<Department, Integer> idColumn;
    @FXML private TableColumn<Department, String> nameColumn;
    @FXML private TableColumn<Department, Integer> locationColumn;
    private ObservableList<Department> departmentsList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("departmentId"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("departmentName"));
        locationColumn.setCellValueFactory(new PropertyValueFactory<>("locationId"));

        departmentsTable.setItems(departmentsList);
        loadDepartments();

        departmentsTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                departmentIdField.setText(String.valueOf(newSelection.getDepartmentId()));
                departmentNameField.setText(newSelection.getDepartmentName());
                locationIdField.setText(String.valueOf(newSelection.getLocationId()));
            }
        });
    }

    @FXML
    private void addDepartment() {
        System.out.println("Add Department button clicked");
        String id = departmentIdField.getText();
        String name = departmentNameField.getText();
        String location = locationIdField.getText();

        try (Connection conn = DatabaseConnection.getConnection()) {
            String query = "INSERT INTO departments (department_id, department_name, location_id) VALUES (?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, id);
            pstmt.setString(2, name);
            pstmt.setString(3, location);
            pstmt.executeUpdate();
            loadDepartments();
            showAlert("Success", "Department added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Database Error", "Could not add department.");
        }
    }

    @FXML
    private void updateDepartment() {
        System.out.println("Update Department button clicked");
        String id = departmentIdField.getText();
        String name = departmentNameField.getText();
        String location = locationIdField.getText();

        try (Connection conn = DatabaseConnection.getConnection()) {
            String query = "UPDATE departments SET department_name = ?, location_id = ? WHERE department_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, name);
            pstmt.setString(2, location);
            pstmt.setString(3, id);
            pstmt.executeUpdate();
            loadDepartments();
            showAlert("Success", "Department updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Database Error", "Could not update department.");
        }
    }

    @FXML
    private void deleteDepartment() {
        System.out.println("Delete Department button clicked");
        String id = departmentIdField.getText();

        try (Connection conn = DatabaseConnection.getConnection()) {
            String query = "DELETE FROM departments WHERE department_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, id);
            pstmt.executeUpdate();
            loadDepartments();
            showAlert("Success", "Department deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Database Error", "Could not delete department.");
        }
    }

    private void loadDepartments() {
        departmentsList.clear();
        try (Connection conn = DatabaseConnection.getConnection()) {
            String query = "SELECT department_id, department_name, location_id FROM departments";
            PreparedStatement pstmt = conn.prepareStatement(query);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                departmentsList.add(new Department(rs.getInt("department_id"), rs.getString("department_name"), rs.getInt("location_id")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Database Error", "Could not load departments.");
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
