package com.example.demo12;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

public class LoginController {
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;

    private int loginAttempts = 0;
    private static final int MAX_ATTEMPTS = 5;

    @FXML
    public void handleLogin() {
        String username = usernameField.getText();
        String password = passwordField.getText();

        if (loginAttempts >= MAX_ATTEMPTS) {
            showAlert("Login Blocked", "Too many failed attempts. The application will now close.");
            Stage stage = (Stage) usernameField.getScene().getWindow();
            stage.close();
            return;
        }

        // Check for hardcoded credentials
        if ("lovish batra".equals(username) && "lovish28".equals(password)) {
            showAlert("Login Successful", "Welcome " + username);
            openDatabaseGUI();
        } else {
            loginAttempts++;
            showAlert("Login Failed", "Invalid username or password. Attempts left: " + (MAX_ATTEMPTS - loginAttempts));
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    private void openDatabaseGUI() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("DepartmentsView.fxml"));
            Parent root = loader.load();
            DepartmentsController controller = loader.getController();
            // You might want to pass some data to the DepartmentsController
            // controller.setUserData(userData);

            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.setTitle("Departments Management");
            stage.show();

            // Close the login window
            Stage loginStage = (Stage) usernameField.getScene().getWindow();
            loginStage.close();

        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Could not open Departments Management window.");
        }
    }
}
