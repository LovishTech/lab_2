package com.example.demo12;

public class LoginModel {
    public static boolean authenticate(String username, String password) {
        return "lovish batra".equals(username) && "lovish28".equals(password);
    }
}
